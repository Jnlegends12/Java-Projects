package processor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Map;
import java.util.Map.Entry;

public class ListOfItems extends Items {

	public ListOfItems(String fileName, Map<String, Double> productPrices) {
		super(fileName, productPrices);
	}

	@Override
	public void run() {
		try {
			//Using a BufferedReader to read the clients id 
			BufferedReader reader = new BufferedReader(new FileReader(referenceFile));
			String customersId = reader.readLine(); 
			System.out.println("Reading order for client with id: " + customersId);
			String orderLine;
			while ((orderLine = reader.readLine()) != null) {
				String[] orderData = orderLine.split(" "); 
				String copy = orderData[0];
				if (systemOrders.containsKey(copy)) {
					int tracker = systemOrders.get(copy);
					systemOrders.put(copy, tracker + 1);
				} else {
					systemOrders.put(copy, 1);
				}
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}

	@Override
	//This is where we would return the total of everything 
	public double getTotal() {
		double sumOfProducts = 0;
		for (Entry<String, Integer> tracker : systemOrders.entrySet()) {
			String productName = tracker.getKey();
			int quantity = tracker.getValue();
			double value = orderPrices.getOrDefault(productName, 0.0);
			sumOfProducts += quantity * value;
		}
		return sumOfProducts;
	}

	@Override
	//This where we would print out the information about each item 
	public String toString() {
		NumberFormat formattor = NumberFormat.getCurrencyInstance();
		String toReturn = "";
		for (Map.Entry<String, Integer> tracker : systemOrders.entrySet()) {
			if (tracker.getValue() > 0) {
				toReturn += "Item's name: " + tracker.getKey() + ", " + "Cost per item: "
						+ formattor.format(orderPrices.get(tracker.getKey())) + ", Quantity: " + tracker.getValue()
						+ ", Cost: " + formattor.format(tracker.getValue() * orderPrices.get(tracker.getKey())) + "\n";
			}
		}
		toReturn += "Order Total: " + formattor.format(getTotal()) + "\n";
		return toReturn;
	}

	@Override
	//Here we are simply just obtaining the products 
	public int get(String product) {
		return (systemOrders.containsKey(product)) ? systemOrders.get(product) : 0;
	}

}
