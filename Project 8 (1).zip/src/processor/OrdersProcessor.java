package processor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.TreeMap;
import java.util.Scanner;

public class OrdersProcessor {

	public static void main(String[] args) throws IOException {
		// Here we would create to treemap to hold the data for customers and items
		TreeMap<Integer, ListOfItems> bankOfCustomers = new TreeMap<Integer, ListOfItems>();
		TreeMap<String, Double> costOfItems = new TreeMap<String, Double>();
		// Bringing in the scanner to ask to perfrom threading
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter items's data file name: ");
		String referenceOfFile = scanner.next();
		// This passes in the file specified
		Scanner copy;
		try {
			copy = new Scanner(new File(referenceOfFile));
			while (copy.hasNextLine()) {
				String copyTemp = copy.next();
				Double copyPrice = copy.nextDouble();
				costOfItems.put(copyTemp, copyPrice);
			}
			copy.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// Here we would ask to either perfrom multithreading or single threading
		System.out.println("Enter 'y' for multiple threads, any other character otherwise: ");
		String chooseMultiThread = scanner.next();
		boolean multithreaded = chooseMultiThread.equalsIgnoreCase("y");

		// Amount of items to process
		System.out.println("Enter number of orders to process: ");
		int numberOfOrders = scanner.nextInt();

		// Where it's getting data from
		System.out.println("Enter order's base filename: ");
		String nameOfFile = scanner.next();

		// Where we would find the data
		System.out.println("Enter result's filename: ");
		String resultFile = scanner.next();

		// This is where we woudld return the threading process
		long startTime = System.currentTimeMillis();
		scanner.close();
		if (!multithreaded) {
			// Different methods to utilize the threading and multithreading
			usingSingleThread(nameOfFile, referenceOfFile, numberOfOrders, bankOfCustomers, costOfItems);
		}
		// This is where we would use multithreading
		usingMultiThread(nameOfFile, referenceOfFile, numberOfOrders, bankOfCustomers, costOfItems);

		returnFile(resultFile, costOfItems, bankOfCustomers);
		long endTime = System.currentTimeMillis();
		System.out.println("Processing time (msec): " + (endTime - startTime));
		System.out.println("Results can be found in the file: " + resultFile);
	}

	// Give the option to perfrom mulithreading if wanted to
	private static void usingMultiThread(String nameOfFile, String referenceFileName, int numberOfCustomers,
			TreeMap<Integer, ListOfItems> bankOfCustomers, TreeMap<String, Double> orderPrices) {
		// Create threads for customers
		Thread[] threads = new Thread[numberOfCustomers];
		// This is where we create a lock of customers to allow one thread to get ahold
		// and the others perfoms their task
		synchronized (bankOfCustomers) {
			// Now this creates atomic operations for the methods
			int i = 1;
			while (i <= numberOfCustomers) {
				String fileName = nameOfFile + Integer.toString(i) + ".txt";
				try {
					Scanner scanner = new Scanner(new File(fileName));
					scanner.next();
					// Create another list of items
					ListOfItems copy = new ListOfItems(fileName, orderPrices);
					// Place it into the thread so it can execute waiting till it ends then moving
					// onto the next one
					Thread temp = new Thread(copy);
					threads[i - 1] = temp;
					temp.start();
					// This is where we would place the list into the tree map of customers
					bankOfCustomers.put(scanner.nextInt(), copy);
					i++;
					scanner.close();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			}

		}
		//Here we are for each thread to finish before executing and continuing to the 
		//next steps. 
		int i = 0;
		while (i < threads.length) {
			Thread thread = threads[i];
			try {
				thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			i++;
		}
	}

	// This method is used if you want to perform single threading
	private static void usingSingleThread(String nameOfFile, String referenceFileName, int numberOfCustomers,
			TreeMap<Integer, ListOfItems> bankOfCustomers, TreeMap<String, Double> orderPrices) {
		int i = 1;
		while (i <= numberOfCustomers) {
			String fileName = nameOfFile + Integer.toString(i) + ".txt";
			try {
				// Would perfrom these operations in this order
				Scanner scanner = new Scanner(new File(fileName));
				scanner.next();
				ListOfItems orderTracker = new ListOfItems(fileName, orderPrices);
				orderTracker.run();
				// Waiting for the thread to be executed and then placed into the treemap
				// and then the next thread would go
				bankOfCustomers.put(scanner.nextInt(), orderTracker);
				i++;
				scanner.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

	// This method helps with printing out all the sales associated with the client
	// or customers
	private static void returnFile(String fileToFind, TreeMap<String, Double> costOfItems,
			TreeMap<Integer, ListOfItems> systemOrders) {
		NumberFormat formatter = NumberFormat.getCurrencyInstance();
		try {
			// Pass in the data file into the bufferedwriter
			BufferedWriter writer = new BufferedWriter(new FileWriter(fileToFind));
			// Here were would iterate through the tree to obtain the id
			for (Integer orderId : systemOrders.keySet()) {
				writer.write("----- Order details for client with Id: " + orderId + " -----\n");
				writer.write(systemOrders.get(orderId).toString());
			}
			writer.write("***** Summary of all orders *****" + "\n");
			double total = 0;
			// Now we want to get the products of the orders
			for (String contents : costOfItems.keySet()) {
				int numberOfContents = 0;
				for (ListOfItems items : systemOrders.values()) {
					numberOfContents += items.get(contents);
				}
				// Here we are printing out the total cost of all items along with each
				// individual one
				if (numberOfContents > 0) {
					writer.write("Summary - Item's name: " + contents + ", Cost per item: "
							+ formatter.format(costOfItems.get(contents)) + ", Number sold: " + numberOfContents
							+ ", Item's Total: " + formatter.format(numberOfContents * costOfItems.get(contents))
							+ "\n");
				}
				total += numberOfContents * costOfItems.get(contents);
			}
			//Here we are printing out  the summary of each items for each customers
			writer.write("Summary Grand Total: " + formatter.format(total) + "\n");
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
