package processor;

import java.io.File;
import java.util.Map;
import java.util.TreeMap;

public abstract class Items implements Runnable {
	protected File referenceFile;
	protected Map<String, Double> orderPrices;
	protected Map<String, Integer> systemOrders;

	public Items(String fileName, Map<String, Double> orderPrices) {
		this.referenceFile = new File(fileName);
		this.orderPrices = orderPrices;
		systemOrders = new TreeMap<String, Integer>();
	}

	public abstract void run();

	public abstract double getTotal();

	public abstract int get(String items);
}
